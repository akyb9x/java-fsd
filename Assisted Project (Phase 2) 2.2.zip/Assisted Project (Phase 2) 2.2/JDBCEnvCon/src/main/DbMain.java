package main;

import java.sql.Connection;
import java.sql.SQLException;

import dbUtil.DbUtil;


public class DbMain {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {

		Connection conn = DbUtil.dbConn();
		if(conn!=null) {
			System.out.println("dB connection is established successfully..");
		}
		else {
			System.out.println("No Connection");
		}
	}
}

