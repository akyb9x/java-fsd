package dbUtil;

public class ConstantPool {

	public static final String DRIVER_CLASS = "com.mysql.cj.jdbc.Driver";
	public static final String DB_URL = "jdbc:mysql://localhost:3306/db1";
	public static final String USER = "root";
	public static final String PASSWORD = "password";
}
