package dbUtil;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;



public class DbUtil {

	public static Connection dbConn() throws ClassNotFoundException, SQLException{
		//Register the driver
		Class.forName(ConstantPool.DRIVER_CLASS);
		
		//connection with the dB
		Connection conn = DriverManager.getConnection(ConstantPool.DB_URL,ConstantPool.USER,ConstantPool.PASSWORD);
		return conn;
		}
}
