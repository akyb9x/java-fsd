package linearsearch;

import java.util.Arrays;
import java.util.Scanner;

public class LinearSearch {

	public static void main(String[] args){

		int[] array = {12,25,37,43,55};
		System.out.println("Array is : " + Arrays.toString(array));
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the element to be searched");
		
		int searchValue = sc.nextInt();
		int result = (int) linear(array,searchValue);

		if(result==-1){

			System.out.println("Element not in the array");
		} else {

			System.out.println("Element found at "+result+" and the search key is "+array[result]);
		}

	}

	public static int linear(int arr[], int x) {

		for (int i = 0; i < arr.length - 1; i++) {
			if (arr[i] == x) {
				return i;
			}
		}
		return -1;
	}
}
