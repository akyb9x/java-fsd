package com.simp.main;


import java.sql.SQLException;
import java.util.List;
import java.util.Scanner;

import com.simp.dao.ProductDAO_Impl;
import com.simp.pojo.Product;

public class DbMain {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {

		Scanner sc = new Scanner(System.in);
		ProductDAO_Impl dao = null;
		while(true) {
			System.out.println("Menu \n 1. Add Product \n 2. Delete Product \n 3. Update Product \n 4. Rertieve Procut \n 5. Exit");
			System.out.println("Choice please ");

			int ch = sc.nextInt();
			switch(ch) {
			case 1 :
				Product product = new Product();
				System.out.println("Enter product id");
				product.setPid(sc.nextInt());

				System.out.println("Enter product name");
				product.setPname(sc.next());

				System.out.println("Enter product cost");
				product.setCost(sc.nextInt());

				dao = new ProductDAO_Impl();
				
				if(dao.addProduct(product)>0) {
					System.out.println("Product got inserted with details "+product);
				}
				break;

			case 2 :
				System.out.println("Enter the product id you want to delete");
				int pid = sc.nextInt();
				dao = new ProductDAO_Impl();
				dao.deleteProduct(pid);
				
				if(dao.deleteProduct(pid)>0) {
					System.out.println("Product got deleted");
				}
				break;

			case 3 :				
				System.out.println("Enter the product name you want to update");

				dao = new ProductDAO_Impl();
				System.out.println("Enter the product name");
				String pname = sc.next();

				System.out.println("Enter the Id");
				pid = sc.nextInt();

				if(dao.updateProductName(pid,pname)>0) {
				System.out.println("Updated the data");
				}
				else {
					System.out.println("No Update");
				}
				break;

			case 4 :
				dao = new ProductDAO_Impl();
				List<Product> productList = dao.selectProducts();
				for(Product product2: productList) {
					System.out.println(product2);
				}
				break;

			case 5: System.exit(0);
			}

		}
	}
}
