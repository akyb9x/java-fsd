package com.simp.dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
/*Register Driver 
Connection with dB
Prepare a statement 
execute the query 
Close the dB
*/
import java.util.List;
import java.util.Scanner;

import com.simp.dbutil.DbUtil;
import com.simp.pojo.Product;

public class ProductDAO_Impl implements ProductDAO{

	@Override
	public int addProduct(Product product) throws ClassNotFoundException, SQLException {
		Connection conn = DbUtil.dbConn();
		if(conn!=null) {
			System.out.println("dB connection is established successfully..");
		}
		String sql="insert into product values(?,?,?)";
		PreparedStatement st=conn.prepareStatement(sql);
		st.setInt(1, product.getPid());
		st.setString(2,product.getPname());
		st.setInt(3, product.getCost());
		return st.executeUpdate();
	}

	@Override
	public int deleteProduct(int id) throws ClassNotFoundException, SQLException {
		Connection conn = DbUtil.dbConn();
		Scanner sc = new Scanner(System.in);
		
		if(conn!=null) {
			System.out.println("dB connection is established successfully..");
		}
//		Statement st = conn.createStatement();
//		//delete from product where pid = 1
//		String sql = "delete from product where pid="+id;
//		System.out.println(sql);
		String sql = "delete from product where pid=?";
		PreparedStatement st=conn.prepareStatement(sql);
		st.setInt(1, id);
		
		return st.executeUpdate();
	}

	@Override
	public int updateProductName(int id, String name) throws ClassNotFoundException, SQLException {
		Connection conn = DbUtil.dbConn();
		if(conn!=null) {
			System.out.println("dB connection is established successfully..");
		}
		;
		
		String sql = "update product set pname=? where pid=?";
		PreparedStatement st = conn.prepareStatement(sql);
		System.out.println(sql);
		st.setString(1, name);
		st.setInt(2, id);
		return st.executeUpdate();
	}

	@Override
	public List<Product> selectProducts() throws ClassNotFoundException, SQLException {
		Connection conn = DbUtil.dbConn();
		if(conn!=null) {
			System.out.println("dB connection is established successfully..");
		}
		String sql="select * from product";
		
		PreparedStatement st=conn.prepareStatement(sql);
		//select we use st.executeQuery
		ResultSet rs=st.executeQuery();
		
		List<Product> list = new ArrayList<Product>();
		//it gets the base address
		
		while(rs.next()) { //1st row of the table
			Product product = new Product();
			product.setPid(rs.getInt("pid"));
			product.setPname(rs.getString("pname"));
			product.setCost(rs.getInt("pcost"));
			list.add(product);
			}
		return list;
	}

}
