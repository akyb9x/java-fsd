package com.simp.dbutil;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DbUtil {
	
	public static Connection dbConn() throws ClassNotFoundException, SQLException{
	//Register the driver
	Class.forName(DbConstantPool.DRIVER_CLASS);
	
	//connection with the dB
	Connection conn = DriverManager.getConnection(DbConstantPool.DB_URL,DbConstantPool.USER,DbConstantPool.PASSWORD);
	return conn;
	}
}
