
import java.sql.*;

public class DatabaseOperations {
    public static void main(String[] args) {
        String url = "jdbc:mysql://localhost:3306/";
        String user = "root";
        String password = "Qwerty!123";

        try {
            // Create a connection
            Connection connection = DriverManager.getConnection(url, user, password);

            // Create a database
            Statement createStatement = connection.createStatement();
            String createDatabaseQuery = "CREATE DATABASE IF NOT EXISTS mydatabase";
            createStatement.executeUpdate(createDatabaseQuery);
            System.out.println("Database created successfully.");

            // Select the database
            String selectDatabaseQuery = "USE mydatabase";
            createStatement.execute(selectDatabaseQuery);
            System.out.println("Database selected successfully.");

            // Drop the database
            String dropDatabaseQuery = "DROP DATABASE IF EXISTS mydatabase";
            createStatement.executeUpdate(dropDatabaseQuery);
            System.out.println("Database dropped successfully.");

            createStatement.close();
            connection.close();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
