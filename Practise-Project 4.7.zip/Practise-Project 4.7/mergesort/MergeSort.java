package mergesort;

import java.util.Arrays;

public class MergeSort {
	 public static void mergeSort(int[] array) {
	        if (array.length > 1) {
	            // Finding the middle of the array
	            int mid = array.length / 2;

	            // Dividing the array into two halves
	            int[] leftArray = Arrays.copyOfRange(array, 0, mid);
	            int[] rightArray = Arrays.copyOfRange(array, mid, array.length);

	            // Sorting the first and second halves
	            mergeSort(leftArray);
	            mergeSort(rightArray);

	            // Merging the sorted halves
	            merge(array, leftArray, rightArray);
	        }
	    }

	    private static void merge(int[] array, int[] leftArray, int[] rightArray) {
	        int i = 0, j = 0, k = 0;
	        while (i < leftArray.length && j < rightArray.length) {
	            if (leftArray[i] <= rightArray[j]) {
	                array[k] = leftArray[i];
	                i++;
	            } else {
	                array[k] = rightArray[j];
	                j++;
	            }
	            k++;
	        }
	        while (i < leftArray.length) {
	            array[k] = leftArray[i];
	            i++;
	            k++;
	        }
	        while (j < rightArray.length) {
	            array[k] = rightArray[j];
	            j++;
	            k++;
	        }
	    }

	    public static void main(String[] args) {
	        int[] array = {12, 11, 13, 5, 6, 7};
	        System.out.println("Original array: " + Arrays.toString(array));
	        mergeSort(array);
	        System.out.println("Sorted array: " + Arrays.toString(array));
	    }
	}